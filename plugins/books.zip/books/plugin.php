<?php

add_action(
	'plugins_loaded',
	function() {
		if ( get_option( 'pods_imported' ) ) {
			return;
		}
		error_reporting( 0 );

		pods_init()->setup( get_current_blog_id() );
        pods_init()->load_components();
        pods_components()->get_components();
        pods_components()->load();
        if ( ! class_exists( 'Pods_Migrate_Packages' ) ) {
            $_GET['toggle'] = 1;
            pods_components()->toggle( 'migrate-packages' );
            pods_components()->load();
        }
        /*
        if ( ! class_exists( 'Pods_Advanced_Relationships' ) ) {
            $_GET['toggle'] = 1;
            pods_components()->toggle( 'advanced-relationships' );
            pods_components()->load();
        }
        */
        pods_api()->import_package( file_get_contents( __DIR__ . '/pods.json' ) );
        pods_api()->cache_flush_pods();
        if ( ! defined( 'PODS_PRELOAD_CONFIG_AFTER_FLUSH' ) ) {
        	define( 'PODS_PRELOAD_CONFIG_AFTER_FLUSH', true );
        }
        pods_api()->load_pods();

		update_option( 'pods_imported', true );
	}
);